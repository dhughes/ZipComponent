Alagad Zip Component 1.0 for ColdFusion and BlueDragon CD-ROM		
ReadMe Notes

http://www.alagad.com/index.cfm/name-zip

==========================================================================
Table of Contents
This read me file contains the following information.

  Installation Instructions
  Registration Instructions
  CD-ROM Contents
  Known Issues

Installation Instructions
====================
Instructions for installing and using the Alagad Zip Component can be found in
the documentation folder.

To run the examples in the examples folder you will need to create a mapping
named "/Zip" which points to the folder where you placed the Zip.cfc file.

Purchasing Instructions
====================
The Alagad Zip Component is not free software.  Subject to the terms and
conditions of this license you are hereby granted licensed by Alagad Inc. to
install and use one copy of the Alagad Zip Component on one computer for a
period of no more than 30 days from the initial installation.  If you use this
software after the 30 days have lapsed you are required to pay a fee of $50.00
per installation.  Payments can be made at http://www.alagad.com.

For more information see the document 
"Alagad Zip Component 30 Day Evaluation License.rtf"

CD-ROM Contents
====================
This CD-ROM contains a trial version of the Alagad Zip Component and related 
materials.  The folders on this CD-ROM contain the following items.

BlueDragon JX 6.2 Version
The Alagad Zip Component for BlueDragon JX 6.2.

ColdFusion MX 6.1 and MX 7 Version
The Alagad Zip Component for ColdFusion MX 6.1, MX 7 or later.

Documentation
Documentation for the Alagad Zip Component.  Documentation provided in 
Acrobat, HTML, FlashPaper and Microsoft Word formats.

Examples
This folder contains examples demonstrating common usages for the Zip
Component.  Be sure to create a ColdFusion mapping named "/Zip" pointing to
the directory containing the Zip.cfc file so that the examples will work.

Known Issues
====================

There are no known issues at this time.

=======================================================================

Copyright (c) 2004 Alagad Inc. All rights reserved. 

=======================================================================